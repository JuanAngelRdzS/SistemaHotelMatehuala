<?php
$usuario=$_POST['usuario'];
$contraseña=$_POST['contraseña'];
session_start();
$_SESSION['usuario']=$usuario;

$conexion=mysqli_connect("localhost","root","","table_alumnos");

$consulta="SELECT*FROM users where Nom='$usuario' and Key_Users='$contraseña'";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_fetch_array($resultado);

if($filas['id_cargo']==1){ //administrador
    header("location:index_Crud.php");

}else
if($filas['id_cargo']==2){ //cliente
header("location:index_Crud2.php");
}
else{
    ?>
    <?php
    include("login.html");
    ?>
    <h1 class="bad">ERROR EN LA AUTENTIFICACION</h1>
    <?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);
