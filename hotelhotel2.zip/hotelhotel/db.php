<?php

$conexion=mysqli_connect("localhost","root","","table_alumnos");

?>