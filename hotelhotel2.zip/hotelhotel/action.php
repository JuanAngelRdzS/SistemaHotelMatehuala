<?php
include('config.php');
date_default_timezone_set("America/Bogota");
setlocale(LC_ALL, 'es_ES');

$metodoAction  = (int) filter_var($_REQUEST['metodo'], FILTER_SANITIZE_NUMBER_INT);

//$metodoAction ==1, es crear un registro nuevo
if($metodoAction == 1){

    $fechaRegistro  = date('d-m-Y H:i:s A', time()); 
    $namefull       = filter_var($_POST['namefull'], FILTER_SANITIZE_STRING);
    $sexo           = filter_var($_POST['sexo'], FILTER_SANITIZE_STRING);
    $Telefonos      = filter_var($_POST['Telefonos'], FILTER_SANITIZE_STRING);
    $section        = filter_var($_POST['section'], FILTER_SANITIZE_STRING);
    $Fecha_Entrada  = filter_var($_POST['Fecha_Entrada'], FILTER_SANITIZE_STRING);
    $Fecha_Salida   = filter_var($_POST['Fecha_Salida'], FILTER_SANITIZE_STRING);


    //Informacion de la foto
    $filename       = $_FILES["foto"]["name"]; //nombre de la foto
    $tipo_foto      = $_FILES['foto']['type']; //tipo de archivo
    $sourceFoto     = $_FILES["foto"]["tmp_name"]; //url temporal de la foto
    $tamano_foto    = $_FILES['foto']['size']; //tamaño del archivo (foto)

//Se comprueba si la foto a cargar es correcto observando su extensión y tamaño, 100000 = 1 Mega 
if (!((strpos($tipo_foto, "PNG") || strpos($tipo_foto, "jpg") && ($tamano_foto < 100000)))) {
    //código para renombrar la foto 
    $logitudPass 	        = 8;
    $newNameFoto            = substr( md5(microtime()), 1, $logitudPass);
    $explode                = explode('.', $filename);
    $extension_foto         = array_pop($explode);
    $nuevoNameFoto          = $newNameFoto.'.'.$extension_foto;

    //Verificando si existe el directorio, de lo contrario lo creo
    $dirLocal       = "fotosAlumnos";
    if (!file_exists($dirLocal)) {
        mkdir($dirLocal, 0777, true);
    }

    $miDir 		      = opendir($dirLocal); //Habro mi  directorio
    $urlFotoAlumno    = $dirLocal.'/'.$nuevoNameFoto; //Ruta donde se almacena la factura.

    //Muevo la foto a mi directorio.
    if(move_uploaded_file($sourceFoto, $urlFotoAlumno)){
        $SqlInsertAlumno = ("INSERT INTO table_alumnos(
            namefull,
            Telefonos,
            sexo,
            section,
            foto,
            fechaRegistro,
            Fecha_Entrada,
            Fecha_Salida
        )
        VALUES(
            '".$namefull."',
            '".$Telefonos."',
            '".$sexo."',
            '".$section."',
            '".$nuevoNameFoto."',
            '".$fechaRegistro."',
            '".$Fecha_Entrada."',
            '".$Fecha_Salida."'
        )");
        $resulInsert = mysqli_query($con, $SqlInsertAlumno);
        ///print_r( $SqlInsertAlumno);

    }
    closedir($miDir);
    header("Location:index.php?a=1");

  }else{
    header("Location:index.php?errorimg=1");
  }
}


//Actualizar registro del Alumno
if($metodoAction == 2){
    $idAlumno      = (int) filter_var($_REQUEST['id'], FILTER_SANITIZE_NUMBER_INT);

    $namefull       = filter_var($_POST['namefull'], FILTER_SANITIZE_STRING);
    $sexo           = filter_var($_POST['sexo'], FILTER_SANITIZE_STRING);
    $section        = filter_var($_POST['section'], FILTER_SANITIZE_STRING);
    $Telefonos      = filter_var($_POST['Telefonos'], FILTER_SANITIZE_STRING);
    $Fecha_Entrada  = filter_var($_POST['Fecha_Entrada'], FILTER_SANITIZE_STRING);
    $Fecha_Salida   = filter_var($_POST['Fecha_Salida'], FILTER_SANITIZE_STRING);

    $UpdateAlumno    = ("UPDATE table_alumnos
        SET namefull='$namefull',
        sexo='$sexo', 
        section='$section',
        Telefonos='$Telefonos',
        Fecha_Entrada='$Fecha_Entrada',
        Fecha_Salida='$Fecha_Salida'
        WHERE id='$idAlumno' ");
    $resultadoUpdate = mysqli_query($con, $UpdateAlumno);


    //Verificando si existe foto del alumno para actualizar
    if (!empty($_FILES["foto"]["name"])){
            $filename       = $_FILES["foto"]["name"]; //nombre de la foto
            $tipo_foto      = $_FILES['foto']['type']; //tipo de archivo
            $sourceFoto     = $_FILES["foto"]["tmp_name"]; //url temporal de la foto
            $tamano_foto    = $_FILES['foto']['size']; //tamaño del archivo (foto)

            //Se comprueba si el archivo a cargar es correcto observando su extensión y tamaño
        if (!((strpos($tipo_foto, "PNG") || strpos($tipo_foto, "jpg") && ($tamano_foto < 100000)))) {
            $logitudPass 	        = 8;
            $newNameFoto            = substr( md5(microtime()), 1, $logitudPass);
            $explode                = explode('.', $filename);
            $extension_foto         = array_pop($explode);
            $nuevoNameFoto          = $newNameFoto.'.'.$extension_foto;

            //Verificando si existe el directorio, de lo contrario lo creo
            $dirLocal       = "fotosAlumnos";
            $miDir 		      = opendir($dirLocal); //Habro mi  directorio
            $urlFotoAlumno    = $dirLocal.'/'.$nuevoNameFoto; //Ruta donde se almacena la factura.

            //Muevo la foto a mi directorio.
        if(move_uploaded_file($sourceFoto, $urlFotoAlumno)){
            $updateFoto = ("UPDATE table_alumnos SET foto='$nuevoNameFoto' WHERE id='$idAlumno' ");
            $resultFoto = mysqli_query($con, $updateFoto);
        }
    }else{
        header("Location:index.php?errorimg=1");
    }
  }

  header("Location:formEditar.php?update=1&id=$idAlumno");
 }



//Eliminar Alumno
if($metodoAction == 3){
    $idAlumno  = (int) filter_var($_REQUEST['id'], FILTER_SANITIZE_NUMBER_INT);
    $namePhoto = filter_var($_REQUEST['namePhoto'], FILTER_SANITIZE_STRING);

    $SqlDeleteAlumno = ("DELETE FROM table_alumnos WHERE  id='$idAlumno'");
    $resultDeleteAlumno = mysqli_query($con, $SqlDeleteAlumno);
    
    if($resultDeleteAlumno !=0){
        $fotoAlumno = "fotosAlumnos/".$namePhoto;
        unlink($fotoAlumno);
    }
    
    $msj ="Alumno Borrado correctamente.";
    header("Location:index.php?deletAlumno=1&mensaje=".$msj);
 
}

?>